用户账号默认信息：用户名joelongtan，密码jooe008@ai，邮箱joelongtan@163.com。SMTP发件：mailme@yeah.net，授权码DBW8MbYrUNuQf2s9，SMTP服务器smtp.yeah.net:465。QQ邮箱收件：holycow@qq.com。腾讯文档Token：ced2e764c5294e29a949001b40e3d565。WPS知识库Token：9dEIo2l/QYACRw/KbTgC3GoaVqM2kK0JejtNcowyTIdvXa1t36c8OJ/elXXcrp5gCyd8e0hZjNAwyntRYpmaFAPkwIbHd/To9RKVpLdSlRyqyFHm09fbBJQGlZTzepnXbg1POdISZcsjO+/g8Q==。NOIZ AI API：6fec42b3-ed34-4a91-909a-b3863cd5d463$chan.rayson@gmail.com。
§
GitHub backup repos: joelongtanc/hermes-workspace-backup, joelongtanc/openclaw-backup, joelongtanc/openclaw-backup-2026。每日23点自动备份任务已创建 (job_id: bc2046b42713)，备份到 hermes-workspace-backup。
§
美国虾 SSH Bastion（GitHub 代理）：186.244.210.52:8232，密码 VTG8CgXgsFQV。已验证可直接访问 GitHub。无 sshpass，用 SSH_ASKPASS 技巧：DISPLAY=999 SSH_ASKPASS=/tmp/askpass.sh SSH_ASKPASS_REQUIRE=force ssh ...
§
SearXNG 后备搜索已部署（nginx + HTTP Basic Auth），URL/登录信息在 MEMORY.md。
kdocs skill 安装路径：~/skills/kdocs/，金山文档Token环境变量已配置。
用户偏好纯文本格式发信息，方便复制到其他地方。