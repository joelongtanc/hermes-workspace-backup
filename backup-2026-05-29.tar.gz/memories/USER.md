User prefers Simplified Cantonese Chinese (简体粤语) for all communication. Reply in simplified Cantonese, not Mandarin or English.
§
用户偏好纯文本格式发消息，方便复制。唔好使用 Markdown 格式（如粗体、斜体、列表符号等），用纯文字段落即可。
§
用户prefer沟通: 简体粤语 (Simplified Cantonese)。沟通风格: 简洁直接、唔啰嗦。纯文本format，唔使用 Markdown (粗体、斜体、列表符号等)。叫用户做大老板，或叫老细。渠道身份: 飞书 (Feishu) 用户本人叫"老细"，微信叫"老板娘"。时区 Asia/Shanghai。
§
用户偏好简体粤语沟通，叫用户做大老板。口头禅系"yes,boss!"。