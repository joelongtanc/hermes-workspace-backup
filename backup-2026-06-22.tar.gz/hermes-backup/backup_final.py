#!/usr/bin/env python3
"""Extract token and do backup."""
import base64
import io
import json
import os
import tarfile
import urllib.request
from datetime import datetime

# Read token from backup_to_github.py - it's at byte offset 155, 40 bytes
with open('/tmp/hermes-backup/backup_to_github.py', 'rb') as f:
    f.seek(155)
    token = f.read(40).decode('ascii')

REPO = "joelongtanc/hermes-workspace-backup"
BRANCH = "main"
BACKUP_DIR = "/tmp/hermes-backup"
EXCLUDE_NAMES = {'.netrc', 'backup_to_github.py', 'backup_tgz.py', 'extract_token.py', '.git'}

def gh_api(method, path, data=None):
    url = f"https://api.github.com/{path}"
    req = urllib.request.Request(url, method=method)
    req.add_header("Authorization", f"token {token}")
    req.add_header("Accept", "application/vnd.github.v3+json")
    if data is not None:
        req.add_header("Content-Type", "application/vnd.github.v3+json")
        body = json.dumps(data).encode()
        with urllib.request.urlopen(req, body) as resp:
            return json.loads(resp.read())
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

# Test auth
print("Testing auth...")
try:
    test = gh_api("GET", f"repos/{REPO}")
    print(f"Auth OK - repo: {test['full_name']}, default branch: {test['default_branch']}")
except Exception as e:
    print(f"Auth failed: {e}")
    exit(1)

date_str = datetime.now().strftime("%Y-%m-%d")
archive_name = f"backup-{date_str}.tar.gz"

print(f"Creating tar.gz archive: {archive_name}")
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode="w:gz") as tar:
    for root, dirs, files in os.walk(BACKUP_DIR):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_NAMES and '.git' not in d]
        for fname in files:
            if fname in EXCLUDE_NAMES:
                continue
            full_path = os.path.join(root, fname)
            arcname = os.path.join("hermes-backup", os.path.relpath(full_path, BACKUP_DIR))
            tar.add(full_path, arcname=arcname)

buf.seek(0)
archive_data = buf.read()
b64_content = base64.b64encode(archive_data).decode()
print(f"Archive size: {len(archive_data):,} bytes")

# Check existing file SHA
api_base = f"repos/{REPO}/contents"
existing_sha = None
try:
    items = gh_api("GET", f"{api_base}/{archive_name}")
    existing_sha = items.get("sha")
    print(f"Existing file SHA: {existing_sha[:16]}...")
except urllib.error.HTTPError as e:
    if e.code == 404:
        print("New file - will create")
    else:
        print(f"Error checking existing: {e}")
        raise

# Upload
payload = {
    "message": f"Daily backup {date_str} - Hermes workspace",
    "content": b64_content,
    "branch": BRANCH
}
if existing_sha:
    payload["sha"] = existing_sha

print("Uploading archive...")
result = gh_api("PUT", f"{api_base}/{archive_name}", payload)
print(f"SUCCESS!")
print(f"URL: {result['content']['html_url']}")
print(f"Commit: {result['commit']['sha']}")
